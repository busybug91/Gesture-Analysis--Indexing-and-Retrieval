function [covInput]=calCOV(input)
covInput=cov(input);
end
