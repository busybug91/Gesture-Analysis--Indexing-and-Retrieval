package phase2;

import phase1.Consatnts;

public class Constants
{

	public static String pathMatlab=Consatnts.pathMatlab;
			static String pathSampleData="/Users/nitin/Google Drive/workspace/mwdb2/sampleData/";




//	public static String pathSampleData="C:/Users/SONY/Desktop/Dropbox/Multimedia and Web Databases/Projects/Phase 1/sampleDataNew/sampleData/";
//	public static String pathMatlab="cd(\'C:\\Users\\SONY\\Desktop\\Dropbox\\Dropbox\\Workspace\\MWDB2\\resources\')";
	//	C:\Users\SONY\Desktop\Dropbox\Dropbox\Workspace\MWDB2\resources
	//	"cd(\'C:\\Users\\SONY\\Desktop\\Dropbox\\Dropbox\\Workspace\\MWDB2\\resources\')"
	//	"cd(\'C:\\Users\\SONY\\Desktop\')"
	
	//*******Common**********//
	public static int TOTAL_NUMBER_OF_UNIVARIATEDATAS=Consatnts.TOTAL_NUMBER_OF_UNIVARIATEDATAS;
}