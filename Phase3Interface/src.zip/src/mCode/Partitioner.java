package mCode;

public class Partitioner {

}
