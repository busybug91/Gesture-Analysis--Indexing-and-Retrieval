package mCode;
public class PCA implements IDimensionalityReduction {

}
