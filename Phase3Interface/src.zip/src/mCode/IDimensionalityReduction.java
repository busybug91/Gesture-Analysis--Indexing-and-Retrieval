package mCode;

public interface IDimensionalityReduction {

	//what should be the return type??
}
