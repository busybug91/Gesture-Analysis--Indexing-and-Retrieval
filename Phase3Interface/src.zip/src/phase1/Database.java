package phase1;

import java.util.ArrayList;

public class Database {
	
	ArrayList<MultiVriateDataDocument> XAllMultiVariateDocuments;
	ArrayList<MultiVriateDataDocument> YAllMultiVariateDocuments;
	ArrayList<MultiVriateDataDocument> ZAllMultiVariateDocuments;
	ArrayList<MultiVriateDataDocument> WAllMultiVariateDocuments;
	
	public Database()
	{
		XAllMultiVariateDocuments= new ArrayList<MultiVriateDataDocument>();
		YAllMultiVariateDocuments=new ArrayList<MultiVriateDataDocument>();
		ZAllMultiVariateDocuments=new ArrayList<MultiVriateDataDocument>();
		WAllMultiVariateDocuments=new ArrayList<MultiVriateDataDocument>();
		
	}
	
	
	
	

}
