package phase1;

public class Consatnts 
{
	public static int WINDOW_SIZE=4;
	public static int STEP_SIZE=3;
	public static int NUMBER_OF_LEVELS=5;
	public static double MEAN_VALUE=0.0;
	public static double STANDARD_DEVIATION_VALUE=0.25;
	public static String PATH1="C:/Users/SONY/Desktop/Dropbox/Multimedia and Web Databases/Projects/New Data/";
	public static String PATH2="C:/Users/fg4mqr/Desktop/Dropbox/Multimedia and Web Databases/Projects/Phase 1/sampledata/";
	public static String PATH3="C:/Users/SONY/Desktop/Dropbox/Multimedia and Web Databases/Projects/Phase 1/sampleDataNew/sampleData/";
	public static int TOTAL_NUMBER_OF_GESTURES=60;
	public static int TOTAL_NUMBER_OF_UNIVARIATEDATAS=20;
	public static int TOTAL_NUMBER_OF_DOCUMENTS;
	public static String pathMatlab="cd(\'C:\\Users\\asahu3\\Desktop\\resources\')";
//	public static String algo
}
